import GUIs.Login;


public class JavaExample {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Login login = new Login(); 
        login.setVisible(true);
    }
    
}
